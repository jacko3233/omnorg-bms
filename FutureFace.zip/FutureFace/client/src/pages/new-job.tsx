import { ArrowLeft, Save, X, Plus, Trash2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Client, InsertJob, InsertJobItem } from "@shared/schema";

interface CompanyConfig {
  name: string;
  tagline: string;
}

interface JobFormData {
  jobStatus: string;
  pm: string;
  date: string;
  client: string;
  description: string;
  jobType: string;
  linkedJobRef: string;
  jobComments: string;
  purchaseOrder: string;
  attachments: string;
  costNett: string;
  quoteRef: string;
  jobComplete: boolean;
  invoiced: boolean;
  invoiceComments: string;
}

interface JobItemData {
  itemDescription: string;
  itemAssetNo: string;
  onHireDate: string;
  offHireDate: string;
  priceWeek: string;
  comments: string;
}

// White-label configuration
const companyConfig: CompanyConfig = {
  name: "OMNOR GROUP",
  tagline: "Built from the North. Delivered Worldwide."
};

export default function NewJob() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Fetch clients for dropdown
  const { data: clients = [], isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });

  // Create job mutation
  const createJobMutation = useMutation({
    mutationFn: async (jobData: InsertJob) => {
      // First create the job
      const response = await apiRequest('POST', '/api/jobs', jobData);
      const job = await response.json();
      
      // Then create job items if any exist
      const validItems = jobItems.filter(item => item.itemDescription.trim());
      for (const item of validItems) {
        const itemData: InsertJobItem = {
          jobId: job.id,
          itemDescription: item.itemDescription,
          itemAssetNo: item.itemAssetNo || null,
          onHireDate: item.onHireDate ? new Date(item.onHireDate) : null,
          offHireDate: item.offHireDate ? new Date(item.offHireDate) : null,
          priceWeek: item.priceWeek.replace('£', ''),
          comments: item.comments || null,
        };
        await apiRequest('POST', `/api/jobs/${job.id}/items`, itemData);
      }
      
      return job;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Hire job created successfully with all items!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/jobs'] });
      setLocation('/hire');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create job",
        variant: "destructive",
      });
    },
  });

  const [formData, setFormData] = useState<JobFormData>({
    jobStatus: "OPEN",
    pm: "",
    date: new Date().toISOString().split('T')[0],
    client: "",
    description: "",
    jobType: "Hire",
    linkedJobRef: "",
    jobComments: "",
    purchaseOrder: "",
    attachments: "",
    costNett: "0.00",
    quoteRef: "",
    jobComplete: false,
    invoiced: false,
    invoiceComments: ""
  });

  const [jobItems, setJobItems] = useState<JobItemData[]>([{
    itemDescription: "",
    itemAssetNo: "",
    onHireDate: new Date().toISOString().split('T')[0],
    offHireDate: "",
    priceWeek: "0.00",
    comments: ""
  }]);

  const handleInputChange = (field: keyof JobFormData, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleItemChange = (index: number, field: keyof JobItemData, value: string) => {
    setJobItems(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const addJobItem = () => {
    setJobItems(prev => [...prev, {
      itemDescription: "",
      itemAssetNo: "",
      onHireDate: new Date().toISOString().split('T')[0],
      offHireDate: "",
      priceWeek: "0.00",
      comments: ""
    }]);
  };

  const removeJobItem = (index: number) => {
    if (jobItems.length > 1) {
      setJobItems(prev => prev.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.client || !formData.description) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields (Client and Description)",
        variant: "destructive",
      });
      return;
    }

    // Convert form data to database schema
    const jobData: InsertJob = {
      jobStatus: formData.jobStatus as "OPEN" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED",
      pm: formData.pm || null,
      date: new Date(formData.date),
      clientId: formData.client,
      description: formData.description,
      jobType: formData.jobType,
      department: 'HIRE', // Set department for proper filtering
      linkedJobRef: formData.linkedJobRef || null,
      jobComments: formData.jobComments || null,
      purchaseOrder: formData.purchaseOrder || null,
      costNett: formData.costNett.replace('£', ''),
      quoteRef: formData.quoteRef || null,
      jobComplete: formData.jobComplete,
      invoiced: formData.invoiced,
      invoiceComments: formData.invoiceComments || null,
    };

    createJobMutation.mutate(jobData);
  };



  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header Section */}
      <div className="bg-red-600 text-white p-6">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Link href="/hire">
              <button className="flex items-center space-x-2 bg-white text-red-600 rounded-lg p-2 hover:bg-gray-100 transition-colors">
                <ArrowLeft className="w-5 h-5" />
                <span className="font-medium">Back</span>
              </button>
            </Link>
            <div className="bg-white text-red-600 rounded-lg p-3 font-bold text-lg">
              {companyConfig.name.toUpperCase()}
            </div>
            <span className="text-lg font-medium">{companyConfig.tagline}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        {/* Page Title */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">NEW JOB</h1>
          <p className="text-lg text-gray-600">Create a new job record</p>
        </div>

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Left Column */}
            <div className="space-y-6">
              
              {/* Auto-generated Job Info */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <Label className="text-sm font-medium text-blue-700">Auto-Generated Job Information</Label>
                </div>
                <p className="text-sm text-blue-600">
                  Job number and LES code will be automatically generated when this job is created.
                  <br />
                  <span className="font-medium">Job Type: {formData.jobType}</span> → Job LES will start with "LEH"
                </p>
              </div>

              {/* Job Status */}
              <div>
                <Label htmlFor="jobStatus" className="text-sm font-medium text-gray-700 mb-2 block">
                  Job Status
                </Label>
                <Select value={formData.jobStatus} onValueChange={(value) => handleInputChange('jobStatus', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="OPEN">OPEN</SelectItem>
                    <SelectItem value="IN_PROGRESS">IN PROGRESS</SelectItem>
                    <SelectItem value="COMPLETED">COMPLETED</SelectItem>
                    <SelectItem value="CANCELLED">CANCELLED</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* PM */}
              <div>
                <Label htmlFor="pm" className="text-sm font-medium text-gray-700 mb-2 block">
                  PM
                </Label>
                <Select value={formData.pm} onValueChange={(value) => handleInputChange('pm', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Project Manager" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="JL">JL</SelectItem>
                    <SelectItem value="DE">DE</SelectItem>
                    <SelectItem value="ML">ML</SelectItem>
                    <SelectItem value="MR">MR</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Date */}
              <div>
                <Label htmlFor="date" className="text-sm font-medium text-gray-700 mb-2 block">
                  Date
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => handleInputChange('date', e.target.value)}
                />
              </div>

              {/* Client */}
              <div>
                <Label htmlFor="client" className="text-sm font-medium text-gray-700 mb-2 block">
                  Client
                </Label>
                <Select value={formData.client} onValueChange={(value) => handleInputChange('client', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder={clientsLoading ? "Loading clients..." : "Select Client"} />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map((client) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.companyName}
                      </SelectItem>
                    ))}
                    {clients.length === 0 && !clientsLoading && (
                      <SelectItem value="no-clients" disabled>
                        No clients available
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">
                  Manage clients in <Link href="/clients" className="text-blue-600 hover:underline">Client Database</Link> or <Link href="/clients/new" className="text-orange-600 hover:underline">Add New Client</Link>
                </p>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description" className="text-sm font-medium text-gray-700 mb-2 block">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="HIRE -"
                  rows={3}
                />
              </div>

              {/* Job Type */}
              <div>
                <Label htmlFor="jobType" className="text-sm font-medium text-gray-700 mb-2 block">
                  Job Type
                </Label>
                <Select value={formData.jobType} onValueChange={(value) => handleInputChange('jobType', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Job Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Hire">Hire</SelectItem>
                    <SelectItem value="Fixed Price">Fixed Price</SelectItem>
                    <SelectItem value="Service">Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Linked Job Ref */}
              <div>
                <Label htmlFor="linkedJobRef" className="text-sm font-medium text-gray-700 mb-2 block">
                  Linked Job Ref
                </Label>
                <Input
                  id="linkedJobRef"
                  value={formData.linkedJobRef}
                  onChange={(e) => handleInputChange('linkedJobRef', e.target.value)}
                  placeholder="Enter linked job reference..."
                />
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              
              {/* Job Comments */}
              <div>
                <Label htmlFor="jobComments" className="text-sm font-medium text-gray-700 mb-2 block">
                  Job Comments
                </Label>
                <Textarea
                  id="jobComments"
                  value={formData.jobComments}
                  onChange={(e) => handleInputChange('jobComments', e.target.value)}
                  placeholder="Enter job comments..."
                  rows={4}
                />
              </div>

              {/* Purchase Order */}
              <div>
                <Label htmlFor="purchaseOrder" className="text-sm font-medium text-gray-700 mb-2 block">
                  Purchase Order
                </Label>
                <Textarea
                  id="purchaseOrder"
                  value={formData.purchaseOrder}
                  onChange={(e) => handleInputChange('purchaseOrder', e.target.value)}
                  placeholder="Enter purchase order details..."
                  rows={3}
                />
              </div>

              {/* Attachments */}
              <div>
                <Label htmlFor="attachments" className="text-sm font-medium text-gray-700 mb-2 block">
                  Attachments
                </Label>
                <Textarea
                  id="attachments"
                  value={formData.attachments}
                  onChange={(e) => handleInputChange('attachments', e.target.value)}
                  placeholder="Enter attachment details..."
                  rows={3}
                />
              </div>

              {/* Cost Nett */}
              <div>
                <Label htmlFor="costNett" className="text-sm font-medium text-gray-700 mb-2 block">
                  Cost Nett
                </Label>
                <Input
                  id="costNett"
                  value={formData.costNett}
                  onChange={(e) => handleInputChange('costNett', e.target.value)}
                  placeholder="£0.00"
                />
              </div>

              {/* Quote Ref */}
              <div>
                <Label htmlFor="quoteRef" className="text-sm font-medium text-gray-700 mb-2 block">
                  Quote Ref
                </Label>
                <Input
                  id="quoteRef"
                  value={formData.quoteRef}
                  onChange={(e) => handleInputChange('quoteRef', e.target.value)}
                  placeholder="Enter quote reference..."
                />
              </div>

              {/* Checkboxes */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="jobComplete"
                    checked={formData.jobComplete}
                    onCheckedChange={(checked) => handleInputChange('jobComplete', !!checked)}
                  />
                  <Label htmlFor="jobComplete" className="text-sm font-medium text-gray-700">
                    Job Complete
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="invoiced"
                    checked={formData.invoiced}
                    onCheckedChange={(checked) => handleInputChange('invoiced', !!checked)}
                  />
                  <Label htmlFor="invoiced" className="text-sm font-medium text-gray-700">
                    Invoiced
                  </Label>
                </div>
              </div>

              {/* Invoice Comments */}
              <div>
                <Label htmlFor="invoiceComments" className="text-sm font-medium text-gray-700 mb-2 block">
                  Invoice Comments
                </Label>
                <Textarea
                  id="invoiceComments"
                  value={formData.invoiceComments}
                  onChange={(e) => handleInputChange('invoiceComments', e.target.value)}
                  placeholder="Enter invoice comments..."
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Job Items Section */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl text-gray-800">Job Items</CardTitle>
                  <Button
                    type="button"
                    onClick={addJobItem}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Item
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {jobItems.map((item, index) => (
                    <div key={index} className="p-4 border border-gray-200 rounded-lg bg-gray-50">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-medium text-gray-800">Item {index + 1}</h4>
                        {jobItems.length > 1 && (
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeJobItem(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            Item Description *
                          </Label>
                          <Input
                            value={item.itemDescription}
                            onChange={(e) => handleItemChange(index, 'itemDescription', e.target.value)}
                            placeholder="Description of item being hired..."
                          />
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            Asset Number
                          </Label>
                          <Input
                            value={item.itemAssetNo}
                            onChange={(e) => handleItemChange(index, 'itemAssetNo', e.target.value)}
                            placeholder="Asset/Serial number..."
                          />
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            Weekly Price (£)
                          </Label>
                          <Input
                            value={item.priceWeek}
                            onChange={(e) => handleItemChange(index, 'priceWeek', e.target.value)}
                            placeholder="£0.00"
                          />
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            On Hire Date
                          </Label>
                          <Input
                            type="date"
                            value={item.onHireDate}
                            onChange={(e) => handleItemChange(index, 'onHireDate', e.target.value)}
                          />
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            Off Hire Date
                          </Label>
                          <Input
                            type="date"
                            value={item.offHireDate}
                            onChange={(e) => handleItemChange(index, 'offHireDate', e.target.value)}
                          />
                        </div>
                        
                        <div className="md:col-span-1 lg:col-span-1">
                          <Label className="text-sm font-medium text-gray-700 mb-2 block">
                            Comments
                          </Label>
                          <Textarea
                            value={item.comments}
                            onChange={(e) => handleItemChange(index, 'comments', e.target.value)}
                            placeholder="Item-specific comments..."
                            rows={2}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Tip:</strong> Add multiple items for complex hire jobs. Each item can have its own hire dates, pricing, and asset tracking.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-4 mt-8 pt-6 border-t border-gray-200">
            <Button
              type="button"
              variant="outline"
              onClick={() => setLocation('/hire')}
              className="flex items-center space-x-2"
            >
              <X className="w-4 h-4" />
              <span>Cancel</span>
            </Button>
            <Button
              type="submit"
              disabled={createJobMutation.isPending}
              className="bg-red-600 hover:bg-red-700 flex items-center space-x-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{createJobMutation.isPending ? 'Creating...' : 'Create Job'}</span>
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}